B2B SaaS Startup — synthetic sample dataset (ALGOR Analytics)

All data is synthetic and generated for demonstration only. Amounts in Indian rupees (INR).
Period: Apr 2024 - Oct 2026 (Indian financial years; FY 2026-27 to date). Data as of 31 Oct 2026.

Tables:
  rev_monthly: 810 rows
  acq_monthly: 1,060 rows
  fin_monthly: 31 rows
  budget_monthly: 93 rows
  deals_won: 1,197 rows
  churned_accounts: 565 rows
