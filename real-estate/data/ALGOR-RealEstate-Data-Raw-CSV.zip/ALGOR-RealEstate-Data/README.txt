Residential Developer Portfolio — synthetic sample dataset (ALGOR Analytics)

All data is synthetic and generated for demonstration only. Amounts in Indian rupees (INR).
Period: Apr 2024 - Oct 2026 (Indian financial years; FY 2026-27 to date). Data as of 31 Oct 2026.

Tables:
  sales_monthly: 5,805 rows
  inv_monthly: 1,170 rows
  coll_monthly: 234 rows
  ar_monthly: 856 rows
  budget_monthly: 93 rows
  bookings_register: 3,228 rows
