Online Learning Platform — synthetic sample dataset (ALGOR Analytics)

All data is synthetic and generated for demonstration only. Amounts in Indian rupees (INR).
Period: Apr 2024 - Oct 2026 (Indian financial years; FY 2026-27 to date). Data as of 31 Oct 2026.

Tables:
  enrol_monthly: 1,785 rows
  learn_monthly: 1,785 rows
  act_monthly: 357 rows
  week_monthly: 4,284 rows
  budget_monthly: 93 rows
  at_risk_learners: 199 rows
