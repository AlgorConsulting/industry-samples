Global Manufacturing Group — synthetic sample dataset (ALGOR Analytics)

All data is synthetic and generated for demonstration only. Amounts in US dollars.
Period: Jan 2023 - Dec 2025 (calendar financial years). Data as of 31 Dec 2025.

Tables:
  sales_monthly: 10,208 rows
  prod_monthly: 2,552 rows
  down_monthly: 1,914 rows
  defects_monthly: 15,312 rows
  plant_monthly: 319 rows
  budget_monthly: 319 rows
  inv_monthly: 1,276 rows
  sales_orders_sample: 4,800 rows
  work_orders_sample: 4,080 rows
  quality_ncr_log: 1,560 rows
  inventory_monthly_position: 7,656 rows
