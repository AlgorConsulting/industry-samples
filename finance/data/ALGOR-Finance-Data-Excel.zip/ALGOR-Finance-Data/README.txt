Global Banking & Lending Network — synthetic sample dataset (ALGOR Analytics)

All data is synthetic and generated for demonstration only. Amounts in US dollars.
Period: Jan 2023 - Dec 2025 (calendar financial years). Data as of 31 Dec 2025.

Tables:
  loans_monthly: 7,560 rows
  dpd_monthly: 12,600 rows
  dep_monthly: 315 rows
  cust_monthly: 1,890 rows
  budget_monthly: 315 rows
  loan_accounts_sample: 4,080 rows
  collection_cases: 1,320 rows
  customer_register: 3,000 rows
