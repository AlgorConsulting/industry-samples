Global Retail Chain — synthetic sample dataset (ALGOR Analytics)

All data is synthetic and generated for demonstration only. Amounts in US dollars.
Period: Jan 2023 - Dec 2025 (calendar financial years). Data as of 31 Dec 2025.

Tables:
  sales_monthly: 10,144 rows
  traffic_monthly: 317 rows
  budget_monthly: 317 rows
  age_monthly: 1,902 rows
  stock_monthly: 2,536 rows
  sales_transactions_sample: 4,800 rows
  loyalty_customers: 3,000 rows
  inventory_monthly_position: 9,510 rows
