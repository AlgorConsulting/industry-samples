Multi-Specialty Hospital Network — synthetic sample dataset (ALGOR Analytics)

All data is synthetic and generated for demonstration only. Amounts in US dollars.
Period: Jan 2023 - Dec 2025 (calendar financial years). Data as of 31 Dec 2025.

Tables:
  fin_monthly: 10,048 rows
  ops_monthly: 314 rows
  budget_monthly: 314 rows
  ar_monthly: 5,800 rows
  patients_monthly: 1,884 rows
  supply_monthly: 1,884 rows
  patient_bills_sample: 4,800 rows
  admissions_sample: 4,080 rows
  patient_register: 3,000 rows
  supplies_monthly_position: 7,850 rows
